var unidad = 0;

function cambiaACelcius() {
    unidad = "Celcius"
}

function cambiaAFahrenheit() {
    unidad = "Fahrenheit"
}

var Valor = $("#valor").val()
function calcular() {
    alert(`${Valor}`)
}

function calcular2() {
    if (unidad = "Celcius") {
        var Resultado = (Valor * 9/5) + 32
        alert(`La temperatura calculada es ${Resultado} °F`) 
    } else {
        var Resultado = (Valor - 32) * 5/9
        alert(`La temperatura calculada es ${Resultado} °C`)
    }
}
